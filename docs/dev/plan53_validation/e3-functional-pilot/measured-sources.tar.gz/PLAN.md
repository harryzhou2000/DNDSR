# Plan 53 targeted assessments

This independent evidence workspace belongs to the audit-fix checkout only.
Other implementation checkouts and MG/IV experiments are excluded.

E2 pilot: local host, np2, OMP1, Open MPI core binding; generated 16x16 2D
periodic quads and 4x4x4 3D hexes, P3. One fresh MPI process group per profile
(full, sweeps only, sweeps plus WBAP); six rows, each bounded to 120 seconds.
Stop immediately on failed execution, missing records, nonfinite output or
profile mismatch. Numerical acceptance requires matching per-rank bit digests
for the sweep and available WBAP operation. Existing independent UTs remain
the mathematical oracle. Exact table allocation counts and RSS are separate.

If the pilot completes in seconds, extend to 128x128 quads and 16x16x16 hexes,
two trials in opposite profile orders (12 rows, same row bound). Keep np2 to
provide 8,192/2,048 owned cells per rank; this is an isolated-memory assessment,
not a scaling campaign. Peak process RSS includes the mesh/metrics phase and
may therefore hide VR-specific savings. Capture pre/post VmRSS and prior/final
process high-water along with the plan's unique allocation report and known
Runtime scratch. No claim that those bytes include Eigen/std scratch or pools.

`scripts/benchmark/plan53_storage.py` writes source/binary/cache hashes, selected
environment, exact commands, per-row states/timings and raw-log hashes. Logs stay
in `data/plan53-targeted-assessment`; only compact records/report are retained
here. Local timings are observational on a shared noisy host. Matched final
timing needs the approved allocated-node runner and its current build policy.

E7 functional pilot: local np2, OMP1, core-bound MPI, 16x16 periodic quads,
P3. One invocation, 100 acquisitions/phase, one trial, maximum 120 seconds.
Count C++ allocation calls/bytes separately from timing; compare mesh Primary
and CellFlux acquisition, metric/basis/RHS entry, auxiliary begin/complete and
unsplit/core/dependent reconstruction. Preserve frozen mean/coefficient versions;
split reconstruction must match the unsplit output elementwise and remain finite.
No numerical solver trajectory. Abandoned auxiliary entries are never consumed;
refresh them before provenance validation. This pilot establishes executable
behavior and allocations only. Local timing is observational. Use the resulting
runtime estimate to prepare E7 matched small/large cells-per-rank observations
on an ordinary unpinned allocated BSSCA node; no MG/IV work is involved.

E7 matched allocated-node plan: exact source df5a3a75 in a new sparse isolated
BSSCA checkout, canonical externals/venv reused, login build16. One exclusive
amd_256 node chosen by Slurm, 32 ranks maximum, OMP1, 180G,15min. Serial process
groups np32 width32/400, np8 width16/200 give 32 and 5,000 cells/rank. Four
forward/reverse phase-order trials,2,000 entry calls and20 numerical calls per
trial. Each row max300s; whole campaign850s. The validated local pilot completes
in under1s. Record complete commands, build/linkage/source/binary/cache hashes,
actual scheduler node and rank binding, C++new count/bytes and max-rank timings.
No production candidate or lifetime changes. Recommend retain/change only after
the measured entry fraction is separated from mesh/metric/basis/numeric work.
Submission must follow successful pinned build/linkage verification. No node
pinning, other jobs queried, or MG/IV work touched. Stop at first failed row.

E3 functional pilot (not allocated-node timing acceptance): local np2, OMP1,
Open MPI core binding. The opt-in `cfv_benchmark_coefficient_publication` uses
16x16 generated periodic quads. Run P3 flow5 AoS and P2 separate 5+12-component
SoA fields, 100 copy repetitions, four numerical repetitions and two trials
with opposite phase orders. Bound each invocation to120s and stop at the first
failure/missing record/nonfinite output. Two physical allocations represent
flow/species coefficient widths; this does not execute reacting thermodynamics.

Separate production `CommitReconstruction`, the same row-copy loop without
mesh/workspace validation, a frozen-input Jacobi sweep and one degree-order
WBAP pass. Setup/reset, halo fills, barriers and payload checks stay outside
the timed work; timing reductions occur after each batch. Reset all physical
fields before each phase. Retain exact mean generations, coefficient allocation
identity and original persistent bindings. Both copy phases must give exact
owned/ghost payloads against a global-ID formula. Numerical outputs must stay
finite and compute-only phases must retain their coefficient input generation.
Record 16*N_owned*modes*sum(physical component widths) as logical read+write
bytes, not measured hardware traffic. No buffer-swap candidate is implemented.

Keep exact source/binary/cache hashes, environment, affinity, commands, exit
status and raw-log hashes under e3-pilot-20261105; ordinary raw logs stay under
data/plan53-targeted-assessment. This gate establishes the benchmark, not E3
completion. Matched small/large cells-per-rank observations, actual production
sweep/limiter copy counts, RHS fractions and the retain/change decision remain
open. Do not extrapolate a single top-order limiter pass to a full limiter cycle.
